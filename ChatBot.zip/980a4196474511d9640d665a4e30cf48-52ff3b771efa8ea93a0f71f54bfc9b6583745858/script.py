print("welcome user!\nhelp is on the way.")
print("rest assured your in the right hands.")

enter_your_info=input("please enter your name and anything which\ncan help with your query")

print("You said: " +enter_your_info)


